package com.example.tipcalc;

public class TipCalculator {
    float bill;
    float tip;
    TipCalculator(float x, float y)
    {

    }

    void setBill(float f)
    {
        bill = f;
    }
    void setTip(float f)
    {
        tip = f;
    }
    float tipAmount()
    {
        return(bill * tip);
    }
    float totalAmount()
    {
      return ((bill * tip) + bill);
    }



}

